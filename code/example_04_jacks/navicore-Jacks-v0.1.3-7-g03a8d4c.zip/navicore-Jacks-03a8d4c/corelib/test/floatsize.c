#include <stdio.h>

int main(){
  printf("floats are %d bytes.\n",sizeof(float));
  return 0;
}

